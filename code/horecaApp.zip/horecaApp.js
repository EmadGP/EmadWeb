// -------------"Data" ------------- //

let repeat = true

let drank_prijs = {
    fris: 2.00,
    bier: 2.50,
    wijn: 3.00,
}

let drank_aantal = {
    fris: 0,
    bier: 0,
    wijn: 0,
}

// -------------"Functions" ------------- //

function drank () {

    while (true) {
        
        let bestelling = prompt("Wat wilt u bestellen").toLowerCase()

        if (bestelling === "fris") {

            let aantal_fris = parseInt(prompt("Hoeveel fris wilt u bestellen?"));
            let check = Number.isInteger(aantal_fris)

            if (check === true) {
                alert("U heeft " + aantal_fris + " fris besteld");
                drank_aantal.fris += aantal_fris
            }

            else {
                alert("U heeft geen geldig getal ingevoerd");
            }
            
        }

        else if (bestelling === "bier") {

            let aantal_bier = parseInt(prompt("Hoeveel bier wilt u bestellen?"));
            let check = Number.isInteger(aantal_bier)

            if (check === true) {
                alert("U heeft " + aantal_bier + " bier besteld");
                drank_aantal.bier += aantal_bier
            }
            
            else {
                alert("U heeft geen geldig getal ingevoerd");
            }
            
        }
        
        else if (bestelling === "wijn") {
            let aantal_wijn = parseInt(prompt("Hoeveel wijn wilt u bestellen?"));
            let check = Number.isInteger(aantal_wijn)

            if (check === true) {
                alert("U heeft " + aantal_wijn + " wijn besteld");
                drank_aantal.wijn += aantal_wijn
            }
            
            else {
                alert("U heeft geen geldig getal ingevoerd");
            }
            
        }
        else if (bestelling === "stop" ) {
            alert("Tot ziens!");
            repeat = false
            break;
        }

        else {
            alert("Dit ken ik niet");
            repeat = true
        }
    }
}


function prijs_fris() {
    let prijs_fris = drank_prijs.fris * drank_aantal.fris
    return prijs_fris
}

function prijs_bier() {
    let prijs_bier = drank_prijs.bier * drank_aantal.bier
    return prijs_bier
}

function prijs_wijn() {
    let prijs_wijn = drank_prijs.wijn * drank_aantal.wijn
    return prijs_wijn
}

function prijs_totaal() {
    let prijs_totaal = prijs_fris() + prijs_bier() + prijs_wijn()
    return prijs_totaal
}

function bon() {

    

    // Fris bon
    if (drank_aantal.fris > 0 ) {
        document.write("U heeft " + drank_aantal.fris + " fris besteld voor " + prijs_fris() + " euro" + "<br>")
    }

    // Bier bon
    if (drank_aantal.bier > 0 ) {
        document.write("U heeft " + drank_aantal.bier + " bier besteld voor " + prijs_bier() + " euro" + "<br>")
    }
    // Wijn bon
    if (drank_aantal.wijn > 0 ) {
        document.write("U heeft " + drank_aantal.wijn + " wijn besteld voor " + prijs_wijn() + " euro" + "<br>")
    }
}


// -------------"Flow" ------------- //

drank();

document.getElementById("bon").innerHTML += "Hier is uw bon:"
bon();